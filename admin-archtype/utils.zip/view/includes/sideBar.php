      <div class="container-fluid page-body-wrapper">       
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <!-- <li class="nav-item">
              <a class="nav-link" href="<?= LINK; ?>mainCategory">
              <i class="fa fa-calendar menu-icon"></i>
                <span class="menu-title">Main-Category</span>
              </a>
            </li> -->
            <li class="nav-item">
              <a class="nav-link" href="<?= LINK; ?>subCategory">
              <i class="icon-paper menu-icon"></i>
                <span class="menu-title">Sub-Category</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= LINK; ?>post">
              <i class="fa fa-edit menu-icon"></i>
                <span class="menu-title">Projects</span>
              </a>
            </li>
          </ul>
        </nav>